const apiKey = "a1d3bea5f14f4b9ab1853403261405";
const apiUrl = "https://api.weatherapi.com/v1/current.json";

const searchInput = document.querySelector(".search input");
const searchBtn   = document.querySelector(".search button");
const weatherIcon = document.querySelector(".weather-icon");
const weatherDiv  = document.querySelector(".weather");
const errorDiv    = document.querySelector(".error");

// Map WeatherAPI condition codes → local image
function getWeatherImage(conditionCode, isDay) {
  // Thunder
  if ([1087,1273,1276,1279,1282].includes(conditionCode)) return "images/rain.png";
  // Snow / Blizzard / Sleet
  if ([1066,1069,1114,1117,1204,1207,1210,1213,1216,1219,1222,1225,1237,
       1249,1252,1255,1258,1261,1264].includes(conditionCode)) return "images/snow.png";
  // Rain / Freezing rain
  if ([1063,1072,1150,1153,1168,1171,1180,1183,1186,1189,1192,1195,1198,
       1201,1240,1243,1246].includes(conditionCode)) return "images/rain.png";
  // Drizzle
  if ([1072,1150,1153].includes(conditionCode)) return "images/drizzle.png";
  // Mist / Fog / Haze
  if ([1030,1135,1147].includes(conditionCode)) return "images/mist.png";
  // Cloudy / Overcast / Partly cloudy
  if ([1003,1006,1009].includes(conditionCode)) return "images/clouds.png";
  // Clear / Sunny
  if (conditionCode === 1000) return "images/clear.png";
  // Fallback
  return isDay ? "images/clear.png" : "images/clouds.png";
}

async function checkWeather(city) {
  if (!city.trim()) return;

  try {
    const url = `${apiUrl}?key=${apiKey}&q=${encodeURIComponent(city)}&aqi=no`;
    const response = await fetch(url);

    if (response.status === 400 || response.status === 404) {
      // City not found
      weatherDiv.style.display = "none";
      errorDiv.style.display   = "block";
      return;
    }

    if (!response.ok) {
      throw new Error(`HTTP error: ${response.status}`);
    }

    const data = await response.json();

    // Populate UI
    document.querySelector(".city").textContent  = data.location.name;
    document.querySelector(".temp").textContent  = Math.round(data.current.temp_c) + "°C";
    document.querySelector(".humidity").textContent = data.current.humidity + "%";
    document.querySelector(".wind").textContent  = data.current.wind_kph + " km/h";

    const desc = document.querySelector(".description");
    if (desc) desc.textContent = data.current.condition.text;

    weatherIcon.src = getWeatherImage(
      data.current.condition.code,
      data.current.is_day
    );

    // Show weather, hide error
    weatherDiv.style.display = "block";
    errorDiv.style.display   = "none";

  } catch (error) {
    console.error("Weather fetch failed:", error);
    errorDiv.style.display   = "block";
    weatherDiv.style.display = "none";
  }
}

// Search button click
searchBtn.addEventListener("click", () => {
  checkWeather(searchInput.value);
});

// Enter key press
searchInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") checkWeather(searchInput.value);
});

// Load default city on start
checkWeather("New York");
